# Salia Motion Atelier

元画像 `assets/title/Character/salia_title_reach.png` から作った、ローカル専用の2Dモーション試作と素材一式。

## 起動

このフォルダーの `start.ps1` を PowerShell で実行。Node.js が必要です。
またはリポジトリ直下で `node tools/salia-viewer/server.cjs` を実行し、
http://127.0.0.1:4178/tools/salia-viewer/ を開きます。
外部CDN、ネットワークAPI、npm install は再生時に不要です。サーバーは127.0.0.1だけで待ち受けます。

## 動作と操作

- 息遣い：4.8秒周期で上半身を微変形。
- 髪：後ろ髪、横髪、アホ毛に位相をずらした揺れ。
- 服：左右の裾とスカートを腰から離れるほど大きく変形。
- 目パチ：3.2〜5.6秒間隔。元絵の目と生成した閉じ目を0.22秒で補間。
- 各動き0〜150%、速度0.25〜2倍、ズーム70〜180%。
- 一時停止、手動目パチ、閉じ目固定、背景変更、色分け、メッシュ表示、単独パーツ表示、透過PNG保存。
- Spaceキーで再生切り替え。OSの「視差効果を減らす」が有効なら一時停止で開始。

## 納品素材

`assets/title/Character/salia-rig/` に格納。

- `parts/`：15個の元絵切り出しPNGと左右の閉じ目PNG。
- `salia-parts.psd`：1672×941、17レイヤー。閉じ目2レイヤーは非表示。
- `rig.json`：各PNGの配置座標、サイズ、パーツ名、初期パラメータ。
- `eyes-closed.png`：元絵座標に配置した目周辺だけの透過差分。
- `parts-map.png`：分割領域の色分け図。
- `blink-reference.png`：内蔵image_genで生成した閉じ目差分の原出力。背景は不透明な市松模様で、原出力全体を透過素材として使用していません。
- `generation-prompt.txt`：使用した生成プロンプト。

## 方式と制限

**正式なLive2D Cubismモデルではありません。`.cmo3` / `.moc3` / `.model3.json` は未作成です。**
Cubism Editorがこの環境で見つからなかったため、独自WebGLメッシュで指定の4種類の動きを実装しています。
VTube StudioやCubism SDKへそのまま読み込むことはできません。

ビューアは15パーツPNGを配置座標どおり合成し、連続する140×80のグリッドメッシュで変形します。
分割素材の継ぎ目を保つ方式なので、各パーツを自由に回転・移動するリグとは異なります。
切り出しは見えているピクセルの分割で、髪や腕の裏側の描き足しは行っていません。
前髪や顔は一部同じレイヤーです。大きな首振りやポーズ変更を行うCubismモデルへ仕上げるには、
隠れた面の補完、追加分割、ArtMeshとデフォーマの作成、パラメータ設定、Editorからの出力が必要です。
閉じ目はAI生成差分の局所切り出しで、手描きのまぶたリグではありません。

正式な出力工程： https://docs.live2d.com/cubism-editor-manual/export-moc3-motion3-files/

## 素材の再生成

`sharp` と `@napi-rs/canvas` を解決できるNode.js環境で `node tools/salia-viewer/build-assets.cjs`。
共有ライブラリを使う場合は環境変数 `SALIA_NODE_MODULES` に node_modules の絶対パスを設定してください。
このスクリプトは保存済み生成画像から抽出するだけで、AI APIを呼び出しません。
画像生成は内蔵image_genを使用。CLI/APIフォールバックは使用していません。

## 検証

ビルド時に元画像と分割再合成を比較し、不透明・半透明の全ピクセルのRGBAが一致することを確認します。
差分があればビルドを失敗させます。初回検証結果は `rig.json` の `verification` に記録。
元画像は変更していません。既存ゲームには組み込んでいません。
